package com.example.paint;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.FileWriter;
import java.io.IOException;

public class UserManager extends SQLiteOpenHelper {

    public UserManager(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("create table users(id INTEGER PRIMARY KEY AUTOINCREMENT, uname TEXT,email TEXT, password TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public boolean login(String email, String pass){
        boolean flag;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("select * from users where email = '" + email + "' and password = '" + pass + "';", null);
        if(c.getCount()==1){
            flag = true;
            try {
                FileWriter fw = new FileWriter("session");
                fw.write("login");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            flag = false;
        }
        return flag;
    }

    public boolean reg(String name, String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("fname", name);
        cv.put("email", email);
        cv.put("password", password);
        db.insert("users", null, cv);
        return true;
    }

}
