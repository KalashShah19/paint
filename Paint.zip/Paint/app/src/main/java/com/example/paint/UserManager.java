package com.example.paint;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.FileWriter;
import java.io.IOException;

public class UserManager extends SQLiteOpenHelper {

    public UserManager(Context context) {
        super(context, "db", null, 1);
    }

    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("create table user(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT,email TEXT, password TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists user;");
        onCreate(db);
    }

    public void createTbl(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("create table IF NOT EXISTS user(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT,email TEXT, password TEXT);");
    }

    public int login(String email, String pass){
        int uid=0;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("select * from user where email = ? and password = ?", new String[]{email, pass});
        if(c.getCount()!=0){
            c.moveToNext();
            uid = c.getInt(0);
        }
        return uid;
    }

    public boolean reg(String name, String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("fname", name);
        cv.put("email", email);
        cv.put("password", password);
        long i = db.insert("user", null, cv);
        if(i!=-1){
            return true;
        } else {
            return false; }
    }

}